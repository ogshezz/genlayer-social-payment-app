# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }

from dataclasses import dataclass
from genlayer import *

ZERO_ADDRESS = Address("0x0000000000000000000000000000000000000000")

@allow_storage
@dataclass
class UserProfile:
    username: str
    bio: str
    created_at: str

@allow_storage
@dataclass
class SocialPost:
    post_id: u256
    author: Address
    content: str
    created_at: str
    tips_received: u256

@allow_storage
@dataclass
class MoneyRequest:
    request_id: u256
    requester: Address
    payer: Address
    amount: u256
    token: Address
    note: str
    created_at: str
    paid: bool

@allow_storage
@dataclass
class TransactionRecord:
    transaction_id: u256
    sender: Address
    recipient: Address
    amount: u256
    token: Address
    transaction_type: str
    reference_id: u256
    note: str
    timestamp: str
    status: str

@gl.evm.contract_interface
class IERC20:
    class View:
        def balance_of(self, owner: Address) -> u256: ...
    class Write:
        def transfer(self, to: Address, amount: u256) -> bool: ...
        def transfer_from(self, from_address: Address, to: Address, amount: u256) -> bool: ...

@gl.evm.contract_interface
class NativeRecipient:
    class View:
        pass
    class Write:
        pass

class SocialPaymentApp(gl.Contract):
    profiles: TreeMap[Address, UserProfile]
    username_to_address: TreeMap[str, Address]
    posts: TreeMap[u256, SocialPost]
    post_ids: DynArray[u256]
    requests: TreeMap[u256, MoneyRequest]
    request_ids: DynArray[u256]
    transactions: TreeMap[u256, TransactionRecord]
    transaction_ids: DynArray[u256]
    user_transaction_ids: TreeMap[Address, DynArray[u256]]
    following: TreeMap[Address, DynArray[Address]]
    followers: TreeMap[Address, DynArray[Address]]
    next_post_id: u256
    next_request_id: u256
    next_transaction_id: u256
    app_name: str
    version: str

    def __init__(self) -> None:
        self.app_name = "SocialPaymentApp"
        self.version = "1.2.0"
        self.next_post_id = u256(1)
        self.next_request_id = u256(1)
        self.next_transaction_id = u256(1)

    def _timestamp(self) -> str:
        return gl.message_raw["datetime"]

    def _normalize_username(self, username: str) -> str:
        return username.strip().lower()

    def _validate_username(self, username: str) -> str:
        name = self._normalize_username(username)
        if len(name) < 3 or len(name) > 32:
            raise gl.vm.UserError("Username must be 3-32 characters")
        for c in name:
            if not (("a" <= c <= "z") or ("0" <= c <= "9") or c == "_"):
                raise gl.vm.UserError("Username may contain only a-z, 0-9 and underscore")
        return name

    def _validate_bio(self, bio: str) -> None:
        if len(bio) > 500:
            raise gl.vm.UserError("Bio must be 500 characters or less")

    def _require_profile(self, user: Address) -> UserProfile:
        p = self.profiles.get(user, UserProfile("", "", ""))
        if p.username == "":
            raise gl.vm.UserError("User profile does not exist")
        return p

    def _resolve_username(self, username: str) -> Address:
        target = self.username_to_address.get(self._normalize_username(username), ZERO_ADDRESS)
        if target == ZERO_ADDRESS:
            raise gl.vm.UserError("Username does not exist")
        return target

    def _positive(self, amount: u256, message: str) -> None:
        if amount == u256(0):
            raise gl.vm.UserError(message)

    def _record_transaction(self, sender: Address, recipient: Address, amount: u256,
                            token: Address, transaction_type: str, reference_id: u256,
                            note: str) -> u256:
        tx_id = self.next_transaction_id
        self.transactions[tx_id] = TransactionRecord(
            transaction_id=tx_id, sender=sender, recipient=recipient, amount=amount,
            token=token, transaction_type=transaction_type, reference_id=reference_id,
            note=note, timestamp=self._timestamp(), status="submitted")
        self.transaction_ids.append(tx_id)
        a = self.user_transaction_ids[sender]
        a.append(tx_id)
        self.user_transaction_ids[sender] = a
        b = self.user_transaction_ids[recipient]
        b.append(tx_id)
        self.user_transaction_ids[recipient] = b
        self.next_transaction_id = tx_id + u256(1)
        return tx_id

    def _send_gen(self, recipient: Address, amount: u256) -> None:
        self._positive(amount, "Amount must be greater than zero")
        NativeRecipient(recipient).emit_transfer(value=amount)

    def _send_token(self, token: Address, sender: Address, recipient: Address, amount: u256) -> None:
        self._positive(amount, "Amount must be greater than zero")
        if token == ZERO_ADDRESS:
            raise gl.vm.UserError("Token address cannot be zero")
        IERC20(token).emit().transfer_from(sender, recipient, amount)

    @gl.public.write
    def create_profile(self, username: str, bio: str) -> None:
        caller = gl.message.sender_address
        name = self._validate_username(username)
        self._validate_bio(bio)
        if self.profiles.get(caller, UserProfile("", "", "")).username != "":
            raise gl.vm.UserError("Profile already exists")
        if self.username_to_address.get(name, ZERO_ADDRESS) != ZERO_ADDRESS:
            raise gl.vm.UserError("Username is already taken")
        self.profiles[caller] = UserProfile(name, bio, self._timestamp())
        self.username_to_address[name] = caller

    @gl.public.write
    def update_profile(self, bio: str) -> None:
        caller = gl.message.sender_address
        p = self._require_profile(caller)
        self._validate_bio(bio)
        self.profiles[caller] = UserProfile(p.username, bio, p.created_at)

    @gl.public.view
    def get_profile(self, username: str) -> UserProfile:
        return self.profiles[self._resolve_username(username)]

    @gl.public.view
    def get_my_profile(self) -> UserProfile:
        return self._require_profile(gl.message.sender_address)

    @gl.public.view
    def resolve_username(self, username: str) -> Address:
        return self._resolve_username(username)

    @gl.public.write.payable
    def send_gen(self, username: str, note: str) -> None:
        sender = gl.message.sender_address
        recipient = self._resolve_username(username)
        amount = gl.message.value
        self._require_profile(sender)
        self._positive(amount, "Attach some GEN to the transaction")
        if recipient == sender:
            raise gl.vm.UserError("Cannot send GEN to yourself")
        self._record_transaction(sender, recipient, amount, ZERO_ADDRESS, "GEN_PAYMENT", u256(0), note)
        self._send_gen(recipient, amount)

    @gl.public.write
    def send_token(self, username: str, token_address: str, amount: u256, note: str) -> None:
        sender = gl.message.sender_address
        recipient = self._resolve_username(username)
        token = Address(token_address)
        self._require_profile(sender)
        self._positive(amount, "Amount must be greater than zero")
        if token == ZERO_ADDRESS:
            raise gl.vm.UserError("Token address cannot be zero")
        if recipient == sender:
            raise gl.vm.UserError("Cannot send tokens to yourself")
        self._record_transaction(sender, recipient, amount, token, "TOKEN_PAYMENT", u256(0), note)
        self._send_token(token, sender, recipient, amount)

    @gl.public.write
    def request_money(self, username: str, amount: u256, token_address: str, note: str) -> u256:
        requester = gl.message.sender_address
        payer = self._resolve_username(username)
        token = Address(token_address)
        self._require_profile(requester)
        self._positive(amount, "Requested amount must be greater than zero")
        if requester == payer:
            raise gl.vm.UserError("Cannot request money from yourself")
        rid = self.next_request_id
        self.requests[rid] = MoneyRequest(rid, requester, payer, amount, token, note, self._timestamp(), False)
        self.request_ids.append(rid)
        self.next_request_id = rid + u256(1)
        return rid

    @gl.public.view
    def get_request(self, request_id: u256) -> MoneyRequest:
        return self.requests[request_id]

    @gl.public.write.payable
    def pay_request_gen(self, request_id: u256) -> None:
        payer = gl.message.sender_address
        r = self.requests[request_id]
        if r.paid:
            raise gl.vm.UserError("Request already paid")
        if r.payer != payer:
            raise gl.vm.UserError("You are not the payer for this request")
        if r.token != ZERO_ADDRESS:
            raise gl.vm.UserError("This request is for an ERC-20 token, not GEN")
        if gl.message.value != r.amount:
            raise gl.vm.UserError("Attached GEN does not match request amount")
        self.requests[request_id] = MoneyRequest(r.request_id, r.requester, r.payer, r.amount, r.token, r.note, r.created_at, True)
        self._record_transaction(payer, r.requester, r.amount, ZERO_ADDRESS, "REQUEST_PAYMENT", request_id, r.note)
        self._send_gen(r.requester, r.amount)

    @gl.public.write
    def pay_request_token(self, request_id: u256) -> None:
        payer = gl.message.sender_address
        r = self.requests[request_id]
        if r.paid:
            raise gl.vm.UserError("Request already paid")
        if r.payer != payer:
            raise gl.vm.UserError("You are not the payer for this request")
        if r.token == ZERO_ADDRESS:
            raise gl.vm.UserError("This request is for native GEN, not a token")
        self.requests[request_id] = MoneyRequest(r.request_id, r.requester, r.payer, r.amount, r.token, r.note, r.created_at, True)
        self._record_transaction(payer, r.requester, r.amount, r.token, "REQUEST_PAYMENT", request_id, r.note)
        self._send_token(r.token, payer, r.requester, r.amount)

    @gl.public.write
    def create_post(self, content: str) -> u256:
        author = gl.message.sender_address
        self._require_profile(author)
        if len(content.strip()) == 0:
            raise gl.vm.UserError("Post cannot be empty")
        if len(content) > 1000:
            raise gl.vm.UserError("Post is too long")
        pid = self.next_post_id
        self.posts[pid] = SocialPost(pid, author, content, self._timestamp(), u256(0))
        self.post_ids.append(pid)
        self.next_post_id = pid + u256(1)
        return pid

    @gl.public.view
    def get_post(self, post_id: u256) -> SocialPost:
        return self.posts[post_id]

    @gl.public.view
    def get_post_count(self) -> u256:
        return u256(len(self.post_ids))

    @gl.public.view
    def get_post_ids(self, start_index: u256, count: u256) -> DynArray[u256]:
        out: DynArray[u256] = DynArray()
        i = start_index
        end = start_index + count
        while i < end and i < u256(len(self.post_ids)):
            out.append(self.post_ids[i])
            i = i + u256(1)
        return out

    @gl.public.write.payable
    def tip_post(self, post_id: u256, note: str) -> None:
        tipper = gl.message.sender_address
        amount = gl.message.value
        p = self.posts[post_id]
        self._require_profile(tipper)
        self._positive(amount, "Attach some GEN to tip the post")
        if p.author == tipper:
            raise gl.vm.UserError("Cannot tip your own post")
        self.posts[post_id] = SocialPost(p.post_id, p.author, p.content, p.created_at, p.tips_received + amount)
        self._record_transaction(tipper, p.author, amount, ZERO_ADDRESS, "POST_TIP", post_id, note)
        self._send_gen(p.author, amount)

    @gl.public.view
    def get_transaction(self, transaction_id: u256) -> TransactionRecord:
        return self.transactions[transaction_id]

    @gl.public.view
    def get_user_transaction_count(self) -> u256:
        return u256(len(self.user_transaction_ids[gl.message.sender_address]))

    @gl.public.view
    def get_user_transactions(self, start_index: u256, count: u256) -> DynArray[TransactionRecord]:
        ids = self.user_transaction_ids[gl.message.sender_address]
        out: DynArray[TransactionRecord] = DynArray()
        i = start_index
        end = start_index + count
        while i < end and i < u256(len(ids)):
            out.append(self.transactions[ids[i]])
            i = i + u256(1)
        return out

    @gl.public.write
    def follow_user(self, username: str) -> None:
        follower = gl.message.sender_address
        followed = self._resolve_username(username)
        self._require_profile(follower)
        self._require_profile(followed)
        if follower == followed:
            raise gl.vm.UserError("Cannot follow yourself")
        arr = self.following[follower]
        i = u256(0)
        while i < u256(len(arr)):
            if arr[i] == followed:
                raise gl.vm.UserError("Already following this user")
            i = i + u256(1)
        arr.append(followed)
        self.following[follower] = arr
        arr2 = self.followers[followed]
        arr2.append(follower)
        self.followers[followed] = arr2

    @gl.public.write
    def unfollow_user(self, username: str) -> None:
        follower = gl.message.sender_address
        followed = self._resolve_username(username)
        self._require_profile(follower)
        self._require_profile(followed)
        old = self.following[follower]
        found = False
        new: DynArray[Address] = DynArray()
        i = u256(0)
        while i < u256(len(old)):
            if old[i] == followed:
                found = True
            else:
                new.append(old[i])
            i = i + u256(1)
        if not found:
            raise gl.vm.UserError("You are not following this user")
        self.following[follower] = new
        old2 = self.followers[followed]
        new2: DynArray[Address] = DynArray()
        j = u256(0)
        while j < u256(len(old2)):
            if old2[j] != follower:
                new2.append(old2[j])
            j = j + u256(1)
        self.followers[followed] = new2

    @gl.public.view
    def get_following(self) -> DynArray[Address]:
        return self.following[gl.message.sender_address]

    @gl.public.view
    def get_followers(self) -> DynArray[Address]:
        return self.followers[gl.message.sender_address]

    @gl.public.view
    def get_following_count(self) -> u256:
        return u256(len(self.following[gl.message.sender_address]))

    @gl.public.view
    def get_followers_count(self) -> u256:
        return u256(len(self.followers[gl.message.sender_address]))

    @gl.public.view
    def get_app_info(self) -> str:
        return f"{self.app_name} v{self.version}"
