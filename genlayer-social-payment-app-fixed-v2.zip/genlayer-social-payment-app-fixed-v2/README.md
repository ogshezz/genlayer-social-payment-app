# Social Payment App on GenLayer

A social-first payment application implemented as a **GenLayer Intelligent Contract**.

## Features
- User profiles with unique usernames and bios
- Native GEN payments by username
- ERC-20 payments by username
- GEN and ERC-20 money requests
- Social posts up to 1,000 characters
- Native GEN post tips
- Per-user transaction history
- Follow / unfollow system

## Version
**SocialPaymentApp v1.2.0**

## Structure
```text
genlayer-social-payment-app/
├── contract/social_payment_app.py
├── tests/direct/test_social_payment_app.py
├── README.md
└── requirements.txt
```

## GenLayer dependency
The contract starts with:
```python
# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
```

## Validation
- Username: 3–32 chars, only `a-z`, `0-9`, `_`, stored lowercase
- Bio: max 500 chars
- Post: non-blank, max 1,000 chars
- Payments: amount > 0; self-payments rejected
- GEN request payments require exact attached value
- ERC-20 zero address rejected

## ERC-20
The payer must first approve the SocialPaymentApp contract to spend the token amount, then call `send_token()` or `pay_request_token()`. The contract uses `transfer_from()`.

Current GenLayer documentation describes EVM interactions as external messages and notes that hosted Studio does not execute general EVM contract interactions beyond value transfers to EOAs, so ERC-20 flows should be tested in an environment with the required EVM integration. citeturn0search1turn0search3

## Studio deployment
1. Open GenLayer Studio.
2. Create a Python Intelligent Contract.
3. Paste `contract/social_payment_app.py`.
4. Compile.
5. Deploy.
6. Save the contract address.
7. Test the public methods.

## Local validation
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
genvm-lint check contract/social_payment_app.py
pytest tests/direct/ -v
```

The current GenLayer tooling docs recommend `genvm-lint`, direct-mode tests, and Python 3.12+ for local development. citeturn0search4turn0search5

## Main methods
**Profiles:** `create_profile`, `update_profile`, `get_profile`, `get_my_profile`, `resolve_username`

**Payments:** `send_gen`, `send_token`

**Requests:** `request_money`, `get_request`, `pay_request_gen`, `pay_request_token`

**Social:** `create_post`, `get_post`, `get_post_count`, `get_post_ids`, `tip_post`

**History:** `get_transaction`, `get_user_transaction_count`, `get_user_transactions`

**Graph:** `follow_user`, `unfollow_user`, `get_following`, `get_followers`, `get_following_count`, `get_followers_count`

**Metadata:** `get_app_info`

## Example flow
```text
Alice: create_profile("alice", "Building on GenLayer")
Bob:   create_profile("bob", "Designer")
Alice: follow_user("bob")
Bob:   create_post("My first GenLayer post!")
Alice: tip_post(1, "Great post!")
Alice: request_money("bob", 50, ZERO_ADDRESS, "Lunch")
Bob:   pay_request_gen(1)  # attach exactly 50 GEN
Alice: get_user_transactions(0, 20)
```

This is a hackathon/demo contract. Before production use, validate the full payment flow on the target GenLayer environment, especially external EVM/ERC-20 execution.
